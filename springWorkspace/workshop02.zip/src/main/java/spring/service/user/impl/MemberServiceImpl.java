package spring.service.user.impl;

public class MemberServiceImpl {
	
}
