package spring.service.user;

public interface MemberService {

}
