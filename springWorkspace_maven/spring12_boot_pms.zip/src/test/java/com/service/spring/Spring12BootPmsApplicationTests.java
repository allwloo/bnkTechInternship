package com.service.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring12BootPmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
